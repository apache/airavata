CURRENT (as of January 30, 2013) XSEDE APPROVED CAs:

Revision History
-----------------
1/30/2013 [Added DOEGrids CA S/N 0x47 valid 2002-12-5..2018-01-25 12d0da68.* 1c3f2ca8.*]

1/28/2013 [Removed expiring UK EScience CA 53729190.* 367b75c3.*, DOE Grids CA 12d0da68.* 1c3f2ca8.*, and SDSC NPACI CA 9117797f.* b89793e4.*]
 
1/11/2013 [Removed Decommissioned TACC CAs 9a1da9f9 and f30e4b25]

11/1/2012 [Removed expired UK EScience CA certs and files 367b75c3.*, corrected filenames and symlinks for UK EScience CA certs]

8/8/12 [Corrected issues with signing policies of the recently added UK e-science CAs 1b6f5ede and ffc3d59b]

7/23/12 [Added UK eScienceCA 2A and 2B Files from igtf tarball v1.48]

4/11/2011 [Added newly TAGPMA accredited NCSA 2-factor SLCS CA (Added to IGTF distribution 3/26/2012).]

1/4/2012 [Added newly TAGPMA accredited NICS MyProxy CA] 

6/1/2011 [Added KEK GRID CA (TAGPMA Certified)]

5/4/2011 [Added NERSC CA (TAGPMA Certified)]

1/25/2011 [Added OpenSSL 1.x hash symbolic links for *.0, *.signing_policy,
 *.info, & *.namespaces files on Jan 25 2011]


DOE SCIENCE GRID:
-----------------

Added extended CA certificate (S/N 0x47 valid 2002-12-5..2018-01-25 12d0da68.* 1c3f2ca8.*) 2013-01-30

Removed expired CA certificate 2013-01-28

[Updated signing certificates (validity dates extended) & signing_policies for DOEGrids and ESnet, and crl_url for ESnet, Nov 3, 2006]
[Updated CRL URL for DOEGrids CA 1, May 1, 2008 (mccreary)]

1c3f2ca8.0
/DC=org/DC=DOEGrids/OU=Certificate Authorities/CN=DOEGrids CA 1
1c3f2ca8.crl_url
http://crl.doegrids.org/1c3f2ca8/1c3f2ca8.r0
1c3f2ca8.signing_policy

d1b603c3.0
/DC=net/DC=ES/O=ESnet/OU=Certificate Authorities/CN=ESnet Root CA 1
d1b603c3.crl_url
http://www.es.net/CA/d1b603c3/d1b603c3.r0
d1b603c3.signing_policy

IRISGrid (Spain):
-----------------

9dd23746.0
DC=es, DC=irisgrid, CN=IRISGridCA
9dd23746.crl_url
http://www.irisgrid.es/pki/crl/cacrl.pem
9dd23746.signing_policy

NCSA:
-----

[ Verified 13May09 by mccreary, see NCSA_CACL_provenance for details ]
9b95bbf2.0
[ Updated 31Jan11 by jbasney with new Not After date: Apr 2027 ]
C=US, O=National Center for Supercomputing Applications, OU=Certificate Authorities, CN=CACL
http://ca.ncsa.uiuc.edu/9b95bbf2.r0
9b95bbf2.signing_policy

[ Updated 31Jan11 by jbasney with new Not After date: Apr 2027 ]
[ Verified 07Oct09 by mccreary, see NCSA_MyProxy_provenance for details ]
f2e89fe3.0
C=US, O=National Center for Supercomputing Applications, OU=Certificate Authorities, CN=MyProxy
http://ca.ncsa.uiuc.edu/f2e89fe3.r0
f2e89fe3.signing_policy

[ Added 13May09 by mccreary, see NCSA_GridShib_provenance for details ]
e8ac4b61.0
/C=US/O=National Center for Supercomputing Applications/OU=Certificate Authorities/CN=GridShib CA
e8ac4b61.crl_url
http://ca.ncsa.uiuc.edu/e8ac4b61.r0
e8ac4b61.signing_policy

PITTSBURGH SUPERCOMPUTING CENTER:
---------------------------------

[ Verified 23Apr10 by mccreary, see PSC_provenance for details ]
9b88e95b.0
subject= /C=US/O=Pittsburgh Supercomputing Center/CN=PSC Root CA
9b88e95b.crl_url
http://www.psc.edu/ca/crl/9b88e95b.crl
9b88e95b.psc-root.cadesc
9b88e95b.signing_policy

[ Verified 23Apr10 by mccreary, see PSC_provenance for details ]
acc06fda.0
subject= /C=US/O=Pittsburgh Supercomputing Center/CN=PSC Hosts CA
acc06fda.crl_url
http://www.psc.edu/ca/crl/acc06fda.crl
acc06fda.psc-host.cadesc
acc06fda.signing_policy

[ Added 23Apr10 by mccreary, see PSC_provenance for details ]
4b2783ac.0
subject= /C=US/O=Pittsburgh Supercomputing Center/CN=PSC MyProxy CA
4b2783ac.crl_url
http://www.psc.edu/ca/crl/4b2783ac.crl
4b2783ac.psc-myproxy.cadesc
4b2783ac.signing_policy
4b2783ac.info
4b2783ac.namespaces

Purdue University:
------------------

67e8acfa.0
/CN=Purdue TeraGrid RA/OU=Purdue TeraGrid/O=Purdue University/ST=Indiana/C=US
67e8acfa.crl_url
http://tg-ca.purdue.teragrid.org:8080/67e8acfa.r0
67e8acfa.signing_policy

95009ddc.0
/CN=PurdueCA/O=Purdue University/ST=Indiana/C=US
95009ddc.crl_url
http://tg-ca.purdue.teragrid.org:8080/95009ddc.r0
95009ddc.signing_policy


SDSC:
-----

3deda549.0
/C=US/O=SDSC/OU=SDSC-CA/CN=Certificate Authority/UID=certman
3deda549.crl_url
http://www.sdsc.edu/CA/3deda549.r0
3deda549.signing_policy

b89793e4.0
/C=US/O=NPACI/OU=SDSC/CN=Certificate Manager/UID=certman
b89793e4.crl_url
http://www.npaci.edu/CA/b89793e4.r0
b89793e4.signing_policy


TACC:
-----

[ New TACC CA currently under review - added now to permit testing ]

9a1da9f9.0
/C=US/O=UTAustin/OU=TACC/CN=TACC Certification Authority/UID=caman
9a1da9f9.crl_url
http://www.tacc.utexas.edu/CA/CRL
9a1da9f9.signing_policy

[ New TACC root and classic CA added, Dec 2008 (mccreary) ]
684261aa.0 
/DC=EDU/DC=UTEXAS/DC=TACC/O=UT-AUSTIN/CN=TACC Root CA
684261aa.crl_url 
http://www.tacc.utexas.edu/CA/684261aa.r0
684261aa.signing_policy
684261aa.tacc.cadesc
684261aa.tacc.cadesc.sig

e5cc84c2.0 
/DC=EDU/DC=UTEXAS/DC=TACC/O=UT-AUSTIN/CN=TACC Classic CA
e5cc84c2.crl_url
http://www.tacc.utexas.edu/CA/e5cc84c2.r0
e5cc84c2.signing_policy
e5cc84c2.tacc.cadesc
e5cc84c2.tacc.cadesc.sig

See TACC_provenance for signed statement of certificate origin

[ Added 13May09 by mccreary, see TACC_MICS_provenance for details ]
2ac09305.0
/DC=EDU/DC=UTEXAS/DC=TACC/O=UT-AUSTIN/CN=TACC MICS CA
2ac09305.crl_url
http://www.tacc.utexas.edu/CA/2ac09305.r0
2ac09305.signing_policy

UK E-Science CA:
----------------

[ Jan 28, 2013: Removed (again?) EScience CA cert and files 53729190.* 367b75c3.*]

[ Nov 1, 2012: Removed expired EScience CA cert and files 367b75c3.* ]

[ Nov 1, 2012: swapped filenames and links for consistency with other CA cert file naming ]

$ ls -l 877af676.*
lrwxr-xr-x  1 JimMarsteller  staff  10 Nov  1 15:30 877af676.0 -> 1b6f5ede.0
lrwxr-xr-x  1 JimMarsteller  staff  16 Nov  1 15:31 877af676.crl_url -> 1b6f5ede.crl_url
lrwxr-xr-x  1 JimMarsteller  staff  23 Nov  1 15:30 877af676.signing_policy -> 1b6f5ede.signing_policy
$ ls -l 1b6f5ede.*
-rw-r--r--@ 1 JimMarsteller  staff  1367 Jul 11 09:55 1b6f5ede.0
-rw-r--r--@ 1 JimMarsteller  staff    43 Jul 11 10:33 1b6f5ede.crl_url
-rw-r--r--@ 1 JimMarsteller  staff   237 Jul 11 09:55 1b6f5ede.signing_policy
$ ls -l 530f7122.*
lrwxr-xr-x  1 JimMarsteller  staff  10 Nov  1 15:26 530f7122.0 -> ffc3d59b.0
lrwxr-xr-x  1 JimMarsteller  staff  16 Nov  1 15:28 530f7122.crl_url -> ffc3d59b.crl_url
lrwxr-xr-x  1 JimMarsteller  staff  23 Nov  1 15:27 530f7122.signing_policy -> ffc3d59b.signing_policy
$ ls -l ffc3*
-rw-r--r--@ 1 JimMarsteller  staff  1367 Jul 11 10:28 ffc3d59b.0
-rw-r--r--@ 1 JimMarsteller  staff    43 Jul 11 10:33 ffc3d59b.crl_url
-rw-r--r--@ 1 JimMarsteller  staff   237 Jul 11 10:29 ffc3d59b.signing_policy

[ addition of UK eScienceCA 2A and 2B, Jul 2012 (fest) ]
Files from igtf tarball v1.48

877af676.0
877af676.signing_policy
530f7122.0
530f7122.signing_policy

wget https://dist.eugridpma.info/distribution/igtf/current/https://dist.eugridpma.info/distribution/igtf/current/igtf-policy-installation-bundle-1.48.tar.gz

added hashes for v1 as well.

[ removal of old UK eScience certificates and urls, Aug 2008 (shelmire) ]

Files 
adcbc9ef.0
                adcbc9ef.signing_policy
                8175c1cd.0
                8175c1cd.signing_policy

have been removed. The host that was holding these certificates may have been compromised. The UK E-Science CA is no longer honoring them. 

[ Replacement UK eScience certificates, May 2008 (mccreary) ]

Retrieved from
<https://dist.eugridpma.info/distribution/igtf/current/accredited/tgz/>
	ca_UKeScienceRoot-2007-1.21.tar.gz
	ca_UKeScienceCA-2007-1.21.tar.gz
	ca_UKeScienceRoot-1.21.tar.gz
	ca_UKeScienceCA-1.21.tar.gz

on 22May08. Web server presented certificate w/ subject:

	CN = dist.eugridpma.info
	O  = NIKHEF
	OU = PDP
Serial Num = 01:00:00:00:00:01:10:E4:53:B7:A5

from authority:

	CN = Cybertrust Educational CA
	O  = Cybertrust
	OU = Educational CA

Valid from 21Feb07 until 21Feb2010

Fingerprints:
	SHA1	7D:EF:99:28:66:AB:46:91:AE:0C:05:59:8A:F8:69:60:0F:E0:E0:24
	MD5	5D:AE:44:D1:14:F6:E8:8A:BB:EE:AD:3F:7A:1F:13:6D

Updated:	367b75c3.0
		367b75c3.signing_policy
		98ef0ee5.0
		98ef0ee5.signing_policy

*.crl_url files left unchanged, only difference is .pem extension

1c1
< http://ca.grid-support.ac.uk/pub/crl/ca-crl.der
---
> http://ca.grid-support.ac.uk/pub/crl/ca-crl.pem

Also verifiedi:	adcbc9ef.0
		adcbc9ef.signing_policy
		8175c1cd.0
		8175c1cd.signing_policy

Note that *crl_url for these certs also differs in the extension

1c1
< http://ca.grid-support.ac.uk/pub/crl/escience-root-crl.crl
---
> http://ca.grid-support.ac.uk/pub/crl/escience-root-crl.pem

[ New UK eScience CAs November 2007 (cab) ]

367b75c3.0
subject= /C=UK/O=eScienceCA/OU=Authority/CN=UK e-Science CA
367b75c3.crl_url= http://ca.grid-support.ac.uk/pub/crl/ca-crl.pem
367b75c3.signing_policy

98ef0ee5.0
subject= /C=UK/O=eScienceRoot/OU=Authority/CN=UK e-Science Root
98ef0ee5.crl_url= http://ca.grid-support.ac.uk/pub/crl/root-crl.pem
98ef0ee5.signing_policy

[ New UK eScience CAs August 2006 ]
[ As of Nov. 27, 2007 No new certificates will be issued by this CA (cab) ]
[ Updated the CRL URL location to point to an unpublished PEM file (cab) ]
8175c1cd.0
subject= /C=UK/O=eScienceRoot/OU=Authority/L=Root/CN=CA
8175c1cd.crl_url
http://ca.grid-support.ac.uk/pub/crl/escience-root-crl.pem
8175c1cd.signing_policy

adcbc9ef.0
subject= /C=UK/O=eScienceCA/OU=Authority/CN=CA
adcbc9ef.crl_url
http://ca.grid-support.ac.uk/pub/crl/escience-ca-crl.pem
adcbc9ef.signing_policy

[ UDATED Oct. 16 2007 - updated expired certificate URL (jam) ]
[ REMOVED Oct. 1 2007 - purged expired certificat (cab) ]
[ EXPIRING Aug  4 10:36:41 2007 GMT - no new certificates to be issued after Aug 2006 ]
[ previously approved for limited use until 12/31/2003; re-added for Reality-Grid
  users under Bruce Boghosian (Tufts) TeraGrid project 08/18/2004 - dsimmel ]
01621954.0
/C=UK/O=eScience/OU=Authority/CN=CA/emailAddress=ca-operator@grid-support.ac.uk
01621954.crl_url
http://ca.grid-support.ac.uk/cgi-bin/importCRL.pem
01621954.signing_policy


University of Southern California (USC) CA & KCA:
-------------------------------------------------

[ added March 2005 to facilitate SCEC project users ]
[ removed January 2011 due to CA certificate expiration (jbasney) ]

2ca73e82.0
/C=US/ST=California/L=Los Angeles/O=University of Southern California/CN=University of Southern California PKI-Lite CA, release 1/emailAddress=nmiadmin@usc.edu
2ca73e82.crl_url
http://www.usc.edu/isd/services/authx/CA/2ca73e82.r0 
2ca73e82.signing_policy

[ USC Kerberos Certification Authority only issues short term certs for proxy use
  and has no Certificate Revocation List ]

[ USC KCA v2 service certificate fa9c3452.0 expired March 2, 2006 - the new v3 appears below ]
[ USC KCA v3 service certificate b57985f0.0 expired again on March 2, 2006, removed from the tarball, WJL]
b57985f0.0
/C=US/ST=California/L=Los Angeles/O=University of Southern California/OU=Information Services Division/CN=University of Southern California KCA v3/emailAddress=nmiadmin@usc.edu
b57985f0.signing_policy


INFN (Italy) CA:
---------------

[ added March 2006 in preparation for user demo at GGF17 Tokyo May 2006 ]
[ removed as it expired Sept. 18, 2007 ]
49f18420.0
/C=IT/O=INFN/CN=INFN Certification Authority
49f18420.crl_url
http://security.fi.infn.it/CA/crl.pem
49f18420.signing_policy

[ added on Oct. 1, 2007 to reflect the issuing of a new CA (cab) ]
[ Renamed the CRL URL to reflect an upublished PEM encoded file (cab) ]
[ Updated signing policy, May 1, 2009 (mccreary) ]
2f3fadf6.0
/C=IT/O=INFN/CN=INFN CA
http://security.fi.infn.it/CA/INFNCA_crl.pem
2f3fadf6.signing_policy


Dutch Grid and NIKHEF CA:
------------------------

[ added March 2006 in preparation for user demo at GGF17 Tokyo May 2006 ]

16da7552.0
/C=NL/O=NIKHEF/CN=NIKHEF medium-security certification auth
16da7552.crl_url
http://ca.dutchgrid.nl/medium/cacrl.pem
16da7552.signing_policy


AIST (Japan) CA:
---------------

[ added March 2006 for GridRPC Materials Science production runs ]

a317c467.0
/C=JP/O=AIST/OU=GRID/CN=Certificate Authority
a317c467.crl_url
https://www.apgrid.org/CA/AIST/Production/a317c467.r0
a317c467.signing_policy


NERSC SLCS CA:

[ Added Apr 27 2011 per TeraGrid Ticket 198964 ]

$ wget https://dist.eugridpma.info/distribution/igtf/current/igtf-policy-installation-bundle-1.38.tar.gz
--2011-04-27 10:37:26--  https://dist.eugridpma.info/distribution/igtf/current/igtf-policy-installation-bundle-1.38.tar.gz
Resolving dist.eugridpma.info... 194.171.96.74
Connecting to dist.eugridpma.info|194.171.96.74|:443... connected.
HTTP request sent, awaiting response... 200 OK
Length: 150942 (147K) [application/x-gzip]
Saving to: `igtf-policy-installation-bundle-1.38.tar.gz'
100%[======================================>] 150,942      223K/s   in 0.7s    
2011-04-27 10:37:28 (223 KB/s) - `igtf-policy-installation-bundle-1.38.tar.gz' saved [150942/150942]
$ wget https://dist.eugridpma.info/distribution/igtf/current/igtf-policy-installation-bundle-1.38.tar.gz.asc
--2011-04-27 10:37:48--  https://dist.eugridpma.info/distribution/igtf/current/igtf-policy-installation-bundle-1.38.tar.gz.asc
Resolving dist.eugridpma.info... 194.171.96.74
Connecting to dist.eugridpma.info|194.171.96.74|:443... connected.
HTTP request sent, awaiting response... 200 OK
Length: 189 [text/plain]
Saving to: `igtf-policy-installation-bundle-1.38.tar.gz.asc'
100%[======================================>] 189         --.-K/s   in 0s      
2011-04-27 10:37:49 (1.80 MB/s) - `igtf-policy-installation-bundle-1.38.tar.gz.asc' saved [189/189]
$ gpg --verify igtf-policy-installation-bundle-1.38.tar.gz.asc
gpg: Signature made Fri Feb  4 05:14:38 2011 CST using DSA key ID 3CDBBC71
gpg: Good signature from "EUGridPMA Distribution Signing Key 3 <info@eugridpma.org>"
$ tar xfz igtf-policy-installation-bundle-1.38.tar.gz
$ cd igtf-policy-installation-bundle-1.38/src/accredited/
$ cp NERSC-SLCS.* ~/cvs/repo.teragrid.org/security/certificates
$ cd ~/cvs/repo.teragrid.org/security/certificates/
$ mv NERSC-SLCS.pem b93d6240.0
$ mv NERSC-SLCS.info b93d6240.info
$ mv NERSC-SLCS.crl_url b93d6240.crl_url
$ mv NERSC-SLCS.signing_policy b93d6240.signing_policy
$ rm NERSC-SLCS.namespaces 
$ ln -s b93d6240.0 20b7db76.0
$ ln -s b93d6240.signing_policy 20b7db76.signing_policy
